# Testing Help

## Unit and/or Integration tests are NOT REQUIRED

### Standards
If you decide to include tests, then please use **JUnit** as the test framework and adhere to standard conventions.

### Resources
This [Spring Web Test tutorial](https://spring.io/guides/gs/testing-web) and [JUnit 5 guide](https://www.baeldung.com/junit-5) could be useful resources! 
